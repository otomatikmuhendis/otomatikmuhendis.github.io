﻿using ACC.Common;
using ACC.Transfer;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ACC.Core
{
    public class Service : IService
    {
        private IManager _manager;

        public Service(IManager manager)
        {
            _manager = manager;
        }

        public ClusteringDto GetHostClustering()
        {
            var result = new ClusteringDto();

            result.CustomerId = 0;
            result.FranctionOfFleet = 0M;
            result.ResultCode = Enums.ResultCode.InstanceNotFound;

            try
            {
                var hostList = _manager.GetHosts();

                if (hostList.Count == 0)
                {
                    result.ResultCode = Enums.ResultCode.NotFound;
                    return result;
                }
                foreach (var host in hostList)
                {
                    var customer = GroupByCustomer(host.InstanceList).OrderBy(p => p.InstanceList.Count).FirstOrDefault();

                    if (customer != null)
                    {
                        decimal fractionOfFleet = Convert.ToDecimal(customer.InstanceList.Count) / Convert.ToDecimal(host.NumberOfSlots);

                        if (fractionOfFleet > result.FranctionOfFleet)
                        {
                            result.CustomerId = customer.CustomerId;
                            result.FranctionOfFleet = fractionOfFleet;
                            result.ResultCode = Enums.ResultCode.Success;
                        }
                    }
                }

            }
            catch (Exception)
            {
                result.ResultCode = Enums.ResultCode.Error;
            }

            return result;
        }

        public ClusteringDto GetDatacentreClustering()
        {
            
            var result = new ClusteringDto();

            result.CustomerId = 0;
            result.FranctionOfFleet = 0M;
            result.ResultCode = Enums.ResultCode.InstanceNotFound;

            try
            {
                var hostList = _manager.GetHosts();

                if (hostList.Count == 0)
                {
                    result.ResultCode = Enums.ResultCode.NotFound;
                    return result;
                }

                var datacentres = GroupByDatacentres(hostList);

                foreach (var datacentre in datacentres)
                {
                    var customer = GroupByCustomer(datacentre.InstanceList).OrderBy(p => p.InstanceList.Count).FirstOrDefault();

                    if (customer != null)
                    {
                        decimal fractionOfFleet = Convert.ToDecimal(customer.InstanceList.Count) / Convert.ToDecimal(datacentre.TotalNumberOfSlots);

                        if (fractionOfFleet > result.FranctionOfFleet)
                        {
                            result.CustomerId = customer.CustomerId;
                            result.FranctionOfFleet = fractionOfFleet;
                            result.ResultCode = Enums.ResultCode.Success;
                        }
                    }
                }
            }
            catch (Exception)
            {
                result.ResultCode = Enums.ResultCode.Error;
            }
            return result;
        }

        public HostListDto GetAvailableHosts()
        {
            HostListDto list = new HostListDto();
            list.AvailableHosts = new List<int>();
            list.ResultCode = Enums.ResultCode.Success;

            try
            {
                var hostList = _manager.GetHosts();

                if (hostList.Count == 0)
                {
                    list.ResultCode = Enums.ResultCode.NotFound;
                    return list;
                }

                list.AvailableHosts.AddRange(hostList.FindAll(h => h.NumberOfSlots > h.InstanceList.Count).Select(p => p.HostId));
            }
            catch (Exception)
            {
                list.ResultCode = Enums.ResultCode.Error;
            }

            return list;
        }

        public void WriteFile(string statistics)
        {
            _manager.WriteFile(statistics);
        }

        private List<Datacentre> GroupByDatacentres(List<Host> hostList)
        {
            List<Datacentre> resultList = new List<Datacentre>();

            foreach (var host in hostList)
            {
                var dc = resultList.Find(d => d.DatacentreId == host.Datacentre.DatacentreId);

                if (dc != null)
                {
                    dc.HostList.Add(host);
                    dc.InstanceList.AddRange(host.InstanceList);
                    dc.TotalNumberOfSlots += host.NumberOfSlots;
                }
                else
                {
                    host.Datacentre.HostList = new List<Host>();
                    host.Datacentre.HostList.Add(host);
                    host.Datacentre.InstanceList = new List<Instance>();
                    host.Datacentre.InstanceList.AddRange(host.InstanceList);
                    host.Datacentre.TotalNumberOfSlots += host.NumberOfSlots;
                    resultList.Add(host.Datacentre);
                }
            }

            return resultList;
        }

        private List<Customer> GroupByCustomer(List<Instance> instanceList)
        {
            List<Customer> resultList = new List<Customer>();

            foreach (var instance in instanceList)
            {
                var customer = resultList.Find(d => d.CustomerId == instance.Owner.CustomerId);

                if (customer != null)
                {
                    customer.InstanceList.Add(instance);
                }
                else
                {
                    instance.Owner.InstanceList = new List<Instance>();
                    instance.Owner.InstanceList.Add(instance);
                    resultList.Add(instance.Owner);
                }
            }

            return resultList;
        }

        
    }
}
