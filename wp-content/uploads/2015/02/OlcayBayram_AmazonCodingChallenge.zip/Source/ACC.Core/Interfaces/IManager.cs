﻿using ACC.Common;
using System.Collections.Generic;

namespace ACC.Core
{
    public interface IManager
    {
        List<Host> GetHosts();

        void WriteFile(string statistics);
    }
}
