﻿using ACC.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ACC.Core
{
    public interface IRepository
    {
        List<Host> LoadHosts();

        List<Instance> LoadInstances();

        void WriteFile(string statistics);
    }
}
