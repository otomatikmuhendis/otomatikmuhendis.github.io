﻿using System.Collections.Generic;

namespace ACC.Common
{
    public class Host
    {
        public int HostId { get; set; }
        public int NumberOfSlots { get; set; }
        public Datacentre Datacentre { get; set; }
        public List<Instance> InstanceList { get; set; }
    }
}
