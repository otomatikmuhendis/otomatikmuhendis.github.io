﻿using ACC.Core;
using ACC.Common;
using System;
using System.Globalization;
using System.Text;

namespace ACC.UI
{
    class Program
    {
        static void Main(string[] args)
        {
            var cloudService = new Service(new Manager(new Repository(Util.FilePath())));
            
            var hostClustering = cloudService.GetHostClustering();
            var datacentreClustering = cloudService.GetDatacentreClustering();
            var hostList = cloudService.GetAvailableHosts();

            var builder = new StringBuilder();
            switch (hostClustering.ResultCode)
            {
                case Enums.ResultCode.Success:
                    builder.AppendLine(String.Format("HostClustering:{0},{1}", hostClustering.CustomerId, Math.Round(hostClustering.FranctionOfFleet, 3).ToString(CultureInfo.InvariantCulture)));
                    builder.AppendLine(String.Format("DatacentreClustering:{0},{1}", datacentreClustering.CustomerId, Math.Round(datacentreClustering.FranctionOfFleet, 3).ToString(CultureInfo.InvariantCulture)));
                    builder.Append(String.Format("AvailableHosts:{0}", String.Join(",", hostList.AvailableHosts)));
                break;

                case Enums.ResultCode.InstanceNotFound:
                    builder.AppendLine("HostClustering: There is not any instance.");
                    builder.AppendLine("DatacentreClustering: There is not any instance.");
                    builder.Append(String.Format("AvailableHosts:{0}", String.Join(",", hostList.AvailableHosts)));
                break;

                case Enums.ResultCode.NotFound:
                    builder.AppendLine("HostState file not found");
                break;

                case Enums.ResultCode.Error:
                case Enums.ResultCode.IOError:
                    builder.AppendLine("System Error");
                break;

            }
            cloudService.WriteFile(builder.ToString());
        }
    }
}
