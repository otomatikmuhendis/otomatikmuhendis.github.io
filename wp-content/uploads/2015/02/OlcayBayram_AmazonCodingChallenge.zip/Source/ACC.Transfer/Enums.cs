﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACC.Common
{
    public class Enums
    {
        public enum FileType
        {
            HostState,
            InstanceState,
            Statistics
        }

        public enum ResultCode
        {
            Success,
            Error,
            IOError,
            NotFound,
            InstanceNotFound
        }
    }
}
