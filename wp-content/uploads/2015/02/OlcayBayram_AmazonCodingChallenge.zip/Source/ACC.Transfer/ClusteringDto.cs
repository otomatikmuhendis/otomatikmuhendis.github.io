﻿using ACC.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACC.Transfer
{
    public class ClusteringDto
    {
        public int CustomerId { get; set; }
        public decimal FranctionOfFleet { get; set; }
        public Enums.ResultCode ResultCode { get; set; }
    }
}
