﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ACC.Common;

namespace ACC.Test
{
    internal static class TestHelper
    {
        public static List<Host> GetHosts()
        {
            var hostList = new List<Host>();
            var instanceList = new List<Instance>();

            var hostFileList = new List<string>()
            {
                "2,4,0",
                "5,4,0",
                "7,3,0",
                "9,3,1",
                "3,3,1",
                "10,2,2",
                "6,4,2",
                "8,2,2",
            };

            var instanceFileList = new List<string>()
            {
                "1,8,2",
                "2,8,2",
                "3,8,2",
                "4,8,7",
                "5,15,7",
                "6,16,9",
                "7,13,9",
                "8,9,3",
                "9,13,3",
                "10,16,5",
                "11,15,8",
                "12,8,6",
                "13,16,8",
                "14,9,9",
                "15,9,7"
            };

            foreach (var host in hostFileList)
            {
                string[] splittedHost = host.Split(',');
                var newHost = new Host();
                newHost.HostId = Convert.ToInt32(splittedHost[0]);
                newHost.NumberOfSlots = Convert.ToInt32(splittedHost[1]);
                newHost.Datacentre = new Datacentre();
                newHost.Datacentre.DatacentreId = Convert.ToInt32(splittedHost[2]);
                newHost.InstanceList = new List<Instance>();

                hostList.Add(newHost);
            }

            foreach (var instance in instanceFileList)
            {
                string[] splittedInstance = instance.Split(',');
                var newInstance = new Instance();
                newInstance.InstanceId = Convert.ToInt32(splittedInstance[0]);
                newInstance.Owner = new Customer();
                newInstance.Owner.CustomerId = Convert.ToInt32(splittedInstance[1]);
                newInstance.Host = new Host();
                newInstance.Host.HostId = Convert.ToInt32(splittedInstance[2]);

                instanceList.Add(newInstance);

                var host = hostList.Find(d => d.HostId == newInstance.Host.HostId);

                if (host != null)
                {
                    host.InstanceList.Add(newInstance);
                }
            }

            return hostList;
        }
    }
}
