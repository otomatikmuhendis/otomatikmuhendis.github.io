﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ACC.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace ACC.Test
{
    [TestClass]
    public class ValidationTest
    {
        [TestMethod]
        public void Validate_Return_True()
        {
            var line = "2,1,3";

            Assert.IsTrue(ValidationHelper.ValidateLine(line));
        }


        [TestMethod]
        public void Validate_Return_False()
        {
            var line = "2,a,3";

            Assert.IsFalse(ValidationHelper.ValidateLine(line));

            line = "2a,3";

            Assert.IsFalse(ValidationHelper.ValidateLine(line));

            line = "2,a,b";

            Assert.IsFalse(ValidationHelper.ValidateLine(line));
        }
    }


}
