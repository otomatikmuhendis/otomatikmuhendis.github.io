﻿using ACC.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;

namespace ACC.Test
{
    [TestClass]
    public class ServiceTest
    {
        [TestMethod]
        public void GetHostClustering_Gives_Right_Results()
        {
            var mock = new Mock<IManager>();

            mock.Setup(manager => manager.GetHosts()).Returns(TestHelper.GetHosts());

            var service = new Service(mock.Object);

            var hostClustering = service.GetHostClustering();

            Assert.AreEqual(8, hostClustering.CustomerId);
            Assert.AreEqual(0.75M, hostClustering.FranctionOfFleet);
        }

        [TestMethod]
        public void GetDatacentreClustering_Gives_Right_Results()
        {
            var mock = new Mock<IManager>();

            mock.Setup(manager => manager.GetHosts()).Returns(TestHelper.GetHosts());

            var service = new Service(mock.Object);

            var datacentreClustering = service.GetDatacentreClustering();

            Assert.AreEqual(16, datacentreClustering.CustomerId);
            Assert.AreEqual(0.1666666666666666666666666667M, datacentreClustering.FranctionOfFleet);

        }

        [TestMethod]
        public void GetAvailableHosts_Gives_Right_Results()
        {
            var mock = new Mock<IManager>();

            mock.Setup(manager => manager.GetHosts()).Returns(TestHelper.GetHosts());

            var service = new Service(mock.Object);

            var hostListDto = service.GetAvailableHosts();

            Assert.AreEqual(5, hostListDto.AvailableHosts.Count);
            Assert.AreEqual("2,5,3,10,6", String.Join(",", hostListDto.AvailableHosts));
        }
    }
}
