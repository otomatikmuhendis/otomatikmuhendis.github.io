﻿using ACC.Transfer;

namespace ACC.Core
{
    public interface IService
    {
        ClusteringDto GetHostClustering();
        ClusteringDto GetDatacentreClustering();
        HostListDto GetAvailableHosts();
        void WriteFile(string statistics);
    }
}
