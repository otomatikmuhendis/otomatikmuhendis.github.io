﻿using ACC.Common;
using System.Collections.Generic;

namespace ACC.Core
{
    public class Manager : IManager
    {
        private IRepository _repository;
        private List<Host> _hosts;
        private List<Instance> _instances;

        public Manager(IRepository repository)
        {
            _repository = repository;
        }

        private void GroupByHost()
        {
            foreach (var instance in _instances)
            {
                var host = _hosts.Find(d => d.HostId == instance.Host.HostId);

                if (host != null)
                {
                    host.InstanceList.Add(instance);
                }
            }
        }

        public List<Host> GetHosts()
        {
            if (_hosts == null)
            {
                _hosts = _repository.LoadHosts();
                _instances = _repository.LoadInstances();

                GroupByHost();
            }

            return _hosts;
        }

        public void WriteFile(string statistics)
        {
            _repository.WriteFile(statistics);
        }
    }
}
