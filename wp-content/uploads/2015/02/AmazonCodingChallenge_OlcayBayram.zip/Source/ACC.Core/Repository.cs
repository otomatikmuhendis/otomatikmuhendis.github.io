﻿using ACC.Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace ACC.Core
{
    public class Repository : IRepository
    {
        private string _baseFolderLocation;

        public Repository(string baseFolderLocation)
        {
            _baseFolderLocation = baseFolderLocation;
        }

        private List<string> LoadFile(Enums.FileType fileType)
        {
            List<string> resultList = new List<string>();

            var fileName = _baseFolderLocation + "\\";

            switch (fileType)
            {
                case Enums.FileType.HostState:
                    fileName += "HostState.txt";
                    break;
                case Enums.FileType.InstanceState:
                    fileName += "InstanceState.txt";
                    break;
                case Enums.FileType.Statistics:
                    fileName += "Statistics.txt";
                    break;
                default:
                    break;
            }

            try
            {
                using (var reader = new StreamReader(fileName))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (ValidationHelper.ValidateLine(line))
                        {
                            resultList.Add(line);
                        }
                    }
                }
            }
            catch (FileNotFoundException)
            {
                //TODO FileNotFoundException
            }

            return resultList;
        }

        public List<Host> LoadHosts()
        {
            var hostList = LoadFile(Enums.FileType.HostState);

            List<Host> hosts = new List<Host>();

            if (hostList.Count > 0)
            {
                foreach (var host in hostList)
                {
                    string[] splittedHost = host.Split(',');
                    var newHost = new Host();
                    newHost.HostId = Convert.ToInt32(splittedHost[0]);
                    newHost.NumberOfSlots = Convert.ToInt32(splittedHost[1]);
                    newHost.Datacentre = new Datacentre();
                    newHost.Datacentre.DatacentreId = Convert.ToInt32(splittedHost[2]);
                    newHost.InstanceList = new List<Instance>();

                    hosts.Add(newHost);
                }
            }

            return hosts;
        }

        public List<Instance> LoadInstances()
        {
            var instanceList = LoadFile(Enums.FileType.InstanceState);

            List<Instance> instances = new List<Instance>();

            if (instanceList.Count > 0)
            {
                foreach (var instance in instanceList)
                {
                    string[] splittedInstance = instance.Split(',');
                    var newInstance = new Instance();
                    newInstance.InstanceId = Convert.ToInt32(splittedInstance[0]);
                    newInstance.Owner = new Customer();
                    newInstance.Owner.CustomerId = Convert.ToInt32(splittedInstance[1]);
                    newInstance.Host = new Host();
                    newInstance.Host.HostId = Convert.ToInt32(splittedInstance[2]);

                    instances.Add(newInstance);
                }
            }

            return instances;
        }

        public void WriteFile(string statistics)
        {
            TextWriter tw = new StreamWriter(_baseFolderLocation + "\\" + "Statistics.txt");

            tw.Write(statistics);

            tw.Close();
        }
    }
}
