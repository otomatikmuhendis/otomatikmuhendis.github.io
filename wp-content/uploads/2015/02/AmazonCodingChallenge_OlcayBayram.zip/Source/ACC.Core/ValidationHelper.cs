﻿using System.Text.RegularExpressions;

namespace ACC.Core
{
    public static class ValidationHelper
    {
        public static bool ValidateLine(string line)
        {
            var regex = new Regex(@"\d{0,}\,\d{0,}\,\d{0,}");
            var match = regex.Match(line);

            return match.Success;
        }
    }
}
