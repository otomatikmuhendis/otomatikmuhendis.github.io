﻿using System.Collections.Generic;

namespace ACC.Common
{
    public class Customer
    {
        public int CustomerId { get; set; }
        public List<Instance> InstanceList { get; set; }
    }
}
