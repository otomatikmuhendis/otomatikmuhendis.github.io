﻿using System.Collections.Generic;

namespace ACC.Common
{
    public class Datacentre
    {
        public int DatacentreId { get; set; }
        public int TotalNumberOfSlots { get; set; }
        public List<Host> HostList { get; set; }
        public List<Instance> InstanceList { get; set; }
    }
}
