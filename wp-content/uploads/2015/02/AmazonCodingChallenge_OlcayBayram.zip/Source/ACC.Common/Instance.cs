﻿
namespace ACC.Common
{
    public class Instance
    {
        public int InstanceId { get; set; }
        public Customer Owner { get; set; }
        public Host Host { get; set; }
    }
}
