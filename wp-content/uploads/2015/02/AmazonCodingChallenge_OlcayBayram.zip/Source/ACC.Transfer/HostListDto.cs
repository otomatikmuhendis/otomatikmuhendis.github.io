﻿using ACC.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACC.Transfer
{
    public class HostListDto
    {
        public List<int> AvailableHosts { get; set; }
        public Enums.ResultCode ResultCode { get; set; }
    }
}
